import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateEventDescription = async (title: string, mood: string): Promise<string> => {
  if (!apiKey) {
    return "API Key mancante. Impossibile generare la descrizione.";
  }

  try {
    const prompt = `
      Sei un copywriter esperto per un'organizzazione di eventi chiamata 'ONBEVENTI'.
      Scrivi una descrizione breve, accattivante ed emozionante (massimo 3 frasi) per un evento intitolato: "${title}".
      Il tono deve essere: ${mood}.
      Usa delle emoji appropriate.
      Rispondi solo con la descrizione.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Impossibile generare la descrizione al momento.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Errore durante la generazione della descrizione.";
  }
};
